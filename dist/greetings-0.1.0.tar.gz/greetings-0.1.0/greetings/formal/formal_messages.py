def formal_hello(name):
    return f"Greetings, {name}. It is a pleasure to meet you."

def formal_goodbye(name):
    return f"Farewell, {name}. Until we meet again."
